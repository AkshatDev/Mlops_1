from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="It's Google Colab Env", 
    author="Luxxi_Ikaros", 
    packages=find_packages(),
    license="MIT"
)